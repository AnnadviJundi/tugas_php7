<?php 
    include_once 'header.php';
?>
<?php 
    include_once 'home.php';
?>
<?php 
    include_once 'footer.php';
?>